import React, { useState } from 'react';
import {
  IconMapPin,
  IconClock,
  IconUsers,
  IconPhone,
  IconEdit,
  IconSend,
  IconCheckCircle,
  IconShieldCheck,
  IconPackage
} from './Icons';
import { TEAM_STATUSES } from '../data/mockResponseTeams';

export const TeamDetailsModal = ({
  team,
  isOpen = false,
  onClose = () => {},
  onUpdateStatus = () => {},
  onDeploy = () => {},
  onEdit = () => {}
}) => {
  if (!isOpen || !team) return null;

  const [selectedStatus, setSelectedStatus] = useState(team.status);
  const [deploymentTarget, setDeploymentTarget] = useState(team.deployedIncident || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const [feedback, setFeedback] = useState('');

  const formatDate = (dateString) => {
    if (!dateString) return 'Not recently deployed';
    try {
      const d = new Date(dateString);
      return d.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return dateString;
    }
  };

  const handleStatusSave = async () => {
    if (selectedStatus === team.status) return;
    setIsUpdating(true);
    setFeedback('');
    try {
      await onUpdateStatus(team.teamId, selectedStatus);
      setFeedback(`Status changed to ${selectedStatus}.`);
      setTimeout(() => setFeedback(''), 3000);
    } catch {
      setFeedback('Failed to update status.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDeploySubmit = async () => {
    setIsUpdating(true);
    setFeedback('');
    try {
      await onDeploy(team.teamId, deploymentTarget || `${team.assignedArea} Relief Mission`);
      setSelectedStatus('Deployed');
      setFeedback(`Team successfully deployed!`);
      setTimeout(() => setFeedback(''), 3000);
    } catch {
      setFeedback('Failed to deploy team.');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="org-drawer-backdrop" onClick={onClose}>
      <div className="org-drawer-panel" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="org-drawer-header">
          <div className="org-drawer-title-group">
            <div className="org-drawer-code-row">
              <span className="org-incident-code">
                #{team.teamId}
              </span>
              <span style={{
                fontSize: '11px',
                fontWeight: 700,
                color: '#10756F',
                backgroundColor: '#ECFBF8',
                padding: '2px 8px',
                borderRadius: '4px'
              }}>
                {team.teamType}
              </span>
              <span style={{
                fontSize: '11px',
                fontWeight: 700,
                padding: '2px 8px',
                borderRadius: '9999px',
                backgroundColor: team.status === 'Available' ? '#ECFDF5' : (team.status === 'Deployed' ? '#EFF6FF' : '#FFFBEB'),
                color: team.status === 'Available' ? '#047857' : (team.status === 'Deployed' ? '#1D4ED8' : '#B45309')
              }}>
                ● {team.status}
              </span>
            </div>
            <h2 className="org-drawer-title">{team.teamName}</h2>
          </div>
          <button
            className="org-drawer-close-btn"
            onClick={onClose}
            aria-label="Close details"
            type="button"
          >
            &times;
          </button>
        </div>

        {/* Drawer Body */}
        <div className="org-drawer-body">
          {/* Operations & Deployment Card */}
          <div className="org-assignment-card">
            <div className="org-assignment-header">
              <span className="org-assignment-title">
                <IconSend size={15} color="#10756F" />
                <span>Field Deployment & Readiness</span>
              </span>
              <button
                className="org-btn-secondary"
                onClick={() => {
                  onClose();
                  onEdit(team);
                }}
                style={{ height: '30px', padding: '0 10px', fontSize: '11px' }}
                type="button"
              >
                <IconEdit size={12} />
                <span>Edit Team</span>
              </button>
            </div>

            {/* Quick Status Update */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#475569' }}>
                Availability Status:
              </label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <select
                  className="org-team-select"
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                >
                  {TEAM_STATUSES.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
                <button
                  className="org-btn-primary"
                  onClick={handleStatusSave}
                  disabled={isUpdating || selectedStatus === team.status}
                  style={{
                    height: '38px',
                    padding: '0 16px',
                    fontSize: '12px',
                    opacity: selectedStatus === team.status ? 0.6 : 1,
                    cursor: selectedStatus === team.status ? 'default' : 'pointer'
                  }}
                  type="button"
                >
                  Save Status
                </button>
              </div>
            </div>

            {/* Deploy to Mission Input */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '6px' }}>
              <label style={{ fontSize: '11px', fontWeight: 600, color: '#475569' }}>
                Deploy to Incident / Mission Target:
              </label>
              <div style={{ display: 'flex', gap: '8px' }}>
                <input
                  type="text"
                  className="org-team-select"
                  placeholder="e.g. Kelani River Flood Rescue or Kolonnawa Hub"
                  value={deploymentTarget}
                  onChange={(e) => setDeploymentTarget(e.target.value)}
                />
                <button
                  className="org-btn-secondary"
                  onClick={handleDeploySubmit}
                  disabled={isUpdating}
                  style={{
                    height: '38px',
                    padding: '0 16px',
                    fontSize: '12px',
                    borderColor: '#1D4ED8',
                    color: '#1D4ED8',
                    backgroundColor: '#EFF6FF'
                  }}
                  type="button"
                >
                  <IconSend size={12} />
                  <span>Deploy</span>
                </button>
              </div>
            </div>

            {feedback && (
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#047857', fontWeight: 600, marginTop: '4px' }}>
                <IconCheckCircle size={14} color="#047857" />
                <span>{feedback}</span>
              </div>
            )}
          </div>

          {/* Team Leadership & Personnel Grid */}
          <div className="org-drawer-section">
            <div className="org-drawer-section-title">
              <IconUsers size={16} color="#10756F" />
              <span>Leadership & Capacity</span>
            </div>
            <div className="org-detail-grid">
              <div className="org-detail-item">
                <span className="org-detail-label">Team Leader</span>
                <span className="org-detail-value">{team.teamLeader}</span>
              </div>
              <div className="org-detail-item">
                <span className="org-detail-label">Leader Phone</span>
                <a
                  href={`tel:${team.leaderPhone}`}
                  className="org-detail-value"
                  style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#10756F', textDecoration: 'none' }}
                >
                  <IconPhone size={12} color="#10756F" />
                  {team.leaderPhone}
                </a>
              </div>
              <div className="org-detail-item">
                <span className="org-detail-label">Official Email</span>
                <span className="org-detail-value">{team.leaderEmail || 'N/A'}</span>
              </div>
              <div className="org-detail-item">
                <span className="org-detail-label">Personnel Strength</span>
                <span className="org-detail-value" style={{ color: '#10756F', fontWeight: 800 }}>
                  {team.membersCount} Certified Responders
                </span>
              </div>
              <div className="org-detail-item">
                <span className="org-detail-label">Base Station</span>
                <span className="org-detail-value">🏢 {team.baseStation || 'Main Command Hub'}</span>
              </div>
              <div className="org-detail-item">
                <span className="org-detail-label">Last Active Date</span>
                <span className="org-detail-value" style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <IconClock size={12} color="#64748B" />
                  {formatDate(team.lastDeploymentDate)}
                </span>
              </div>
            </div>
          </div>

          {/* Assigned Area & District */}
          <div className="org-drawer-section">
            <div className="org-drawer-section-title">
              <IconMapPin size={15} color="#10756F" />
              <span>Assigned Area of Responsibility</span>
            </div>
            <div className="org-drawer-description-box" style={{ fontWeight: 600, color: '#0F172A' }}>
              📍 {team.assignedArea} • {team.district} District
            </div>
          </div>

          {/* Active Incident if Deployed */}
          {team.status === 'Deployed' && team.deployedIncident && (
            <div className="org-drawer-section">
              <div className="org-drawer-section-title">
                <IconShieldCheck size={15} color="#1D4ED8" />
                <span>Current Mission Assignment</span>
              </div>
              <div style={{
                backgroundColor: '#EFF6FF',
                border: '1px solid #BFDBFE',
                borderRadius: '8px',
                padding: '12px 14px',
                fontSize: '13px',
                fontWeight: 600,
                color: '#1E40AF'
              }}>
                🎯 {team.deployedIncident}
              </div>
            </div>
          )}

          {/* Specialized Equipment */}
          {team.specializedEquipment && team.specializedEquipment.length > 0 && (
            <div className="org-drawer-section">
              <div className="org-drawer-section-title">
                <IconPackage size={15} color="#10756F" />
                <span>Specialized Deployment Equipment</span>
              </div>
              <div className="org-chips-wrap">
                {team.specializedEquipment.map((eq, idx) => (
                  <span key={idx} className="org-relief-chip">
                    <span>🧰</span>
                    <span>{eq}</span>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
