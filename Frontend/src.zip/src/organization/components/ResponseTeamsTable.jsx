import React from 'react';
import {
  IconMapPin,
  IconChevronRight,
  IconAlertTriangle,
  IconPhone,
  IconUsers,
  IconEdit,
  IconSend,
  IconLifeBuoy,
  IconDroplet,
  IconHome,
  IconTruck
} from './Icons';

export const ResponseTeamsTable = ({
  teams = [],
  isLoading = false,
  error = null,
  onViewDetails = () => {},
  onEditTeam = () => {},
  onQuickDeploy = () => {},
  onRetry = () => {},
  onResetFilters = () => {}
}) => {
  const getTypeBadge = (type) => {
    switch (type) {
      case 'Search and Rescue':
        return (
          <span className="org-team-type-badge rescue">
            <IconLifeBuoy size={12} color="#047857" />
            <span>Search & Rescue</span>
          </span>
        );
      case 'Medical Response':
        return (
          <span className="org-team-type-badge medical">
            <span>🩺</span>
            <span>Medical Response</span>
          </span>
        );
      case 'Logistics':
        return (
          <span className="org-team-type-badge logistics">
            <IconTruck size={12} color="#0369A1" />
            <span>Logistics & Fleet</span>
          </span>
        );
      case 'Volunteer Support':
        return (
          <span className="org-team-type-badge volunteer">
            <span>🤝</span>
            <span>Volunteer Support</span>
          </span>
        );
      case 'Relief Distribution':
        return (
          <span className="org-team-type-badge relief">
            <IconHome size={12} color="#6B21A8" />
            <span>Relief Distribution</span>
          </span>
        );
      default:
        return (
          <span className="org-team-type-badge">
            <IconUsers size={12} />
            <span>{type}</span>
          </span>
        );
    }
  };

  const getStatusPill = (status) => {
    switch (status) {
      case 'Available':
        return (
          <span className="org-team-status-pill available">
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#059669' }}></span>
            Available
          </span>
        );
      case 'Deployed':
        return (
          <span className="org-team-status-pill deployed">
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#1D4ED8' }}></span>
            Deployed
          </span>
        );
      case 'On Standby':
        return (
          <span className="org-team-status-pill standby">
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#D97706' }}></span>
            On Standby
          </span>
        );
      case 'Unavailable':
        return (
          <span className="org-team-status-pill unavailable">
            <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#64748B' }}></span>
            Unavailable
          </span>
        );
      default:
        return (
          <span className="org-team-status-pill unavailable">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="org-incidents-table-card">
      <div className="org-table-header-bar">
        <span className="org-table-count-label">
          Field Response Teams Directory ({teams.length} Teams)
        </span>
      </div>

      {/* Loading Skeleton */}
      {isLoading && (
        <div style={{ padding: '24px' }}>
          <div className="org-skeleton-row"></div>
          <div className="org-skeleton-row"></div>
          <div className="org-skeleton-row"></div>
          <div className="org-skeleton-row"></div>
          <div className="org-skeleton-row"></div>
        </div>
      )}

      {/* Error State */}
      {!isLoading && error && (
        <div className="org-state-box">
          <div style={{
            width: '52px',
            height: '52px',
            borderRadius: '50%',
            backgroundColor: '#FEF2F2',
            color: '#DC2626',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <IconAlertTriangle size={26} color="#DC2626" />
          </div>
          <h3 className="org-state-title">Unable to Load Response Teams</h3>
          <p className="org-state-desc">{error}</p>
          <button
            className="org-btn-primary"
            onClick={onRetry}
            style={{ marginTop: '8px' }}
            type="button"
          >
            Retry Connection
          </button>
        </div>
      )}

      {/* Empty State */}
      {!isLoading && !error && teams.length === 0 && (
        <div className="org-state-box">
          <div style={{
            width: '52px',
            height: '52px',
            borderRadius: '50%',
            backgroundColor: '#ECFBF8',
            color: '#10756F',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <IconUsers size={24} color="#10756F" />
          </div>
          <h3 className="org-state-title">No Response Teams Found</h3>
          <p className="org-state-desc">
            No teams match your current search query or filter selection. Try adjusting your search or clearing filters.
          </p>
          <button
            className="org-btn-secondary"
            onClick={onResetFilters}
            style={{ marginTop: '8px' }}
            type="button"
          >
            Clear All Filters
          </button>
        </div>
      )}

      {/* Data Table */}
      {!isLoading && !error && teams.length > 0 && (
        <div className="org-table-responsive">
          <table className="org-incidents-table">
            <thead>
              <tr>
                <th>Team ID</th>
                <th>Team Name</th>
                <th>Team Type</th>
                <th>Team Leader</th>
                <th>Members</th>
                <th>Assigned Area</th>
                <th>Availability</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {teams.map((team) => (
                <tr key={team.teamId}>
                  {/* ID */}
                  <td>
                    <span className="org-incident-code" style={{ fontSize: '12px' }}>
                      #{team.teamId}
                    </span>
                  </td>

                  {/* Name & Base Station */}
                  <td>
                    <div style={{ fontWeight: 700, color: '#0F172A', fontSize: '13px' }}>
                      {team.teamName}
                    </div>
                    {team.baseStation && (
                      <div style={{ fontSize: '11px', color: '#64748B', marginTop: '2px', maxWidth: '220px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={team.baseStation}>
                        🏢 {team.baseStation}
                      </div>
                    )}
                  </td>

                  {/* Type */}
                  <td>
                    {getTypeBadge(team.teamType)}
                  </td>

                  {/* Leader */}
                  <td>
                    <div style={{ fontWeight: 600, color: '#0F172A', fontSize: '13px' }}>
                      {team.teamLeader}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11px', color: '#64748B', marginTop: '2px' }}>
                      <IconPhone size={11} color="#10756F" />
                      <span>{team.leaderPhone}</span>
                    </div>
                  </td>

                  {/* Number of Members */}
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '5px', fontWeight: 700, color: '#10756F' }}>
                      <IconUsers size={13} color="#10756F" />
                      <span>{team.membersCount} Responders</span>
                    </div>
                  </td>

                  {/* Assigned Area & District */}
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontWeight: 600, color: '#334155' }}>
                      <IconMapPin size={13} color="#64748B" />
                      <span>{team.district}</span>
                    </div>
                    <div style={{ fontSize: '11px', color: '#64748B', marginTop: '2px' }}>
                      {team.assignedArea}
                    </div>
                  </td>

                  {/* Availability Status */}
                  <td>
                    {getStatusPill(team.status)}
                    {team.status === 'Deployed' && team.deployedIncident && (
                      <div style={{ fontSize: '10px', color: '#1D4ED8', marginTop: '3px', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={team.deployedIncident}>
                        🎯 {team.deployedIncident}
                      </div>
                    )}
                  </td>

                  {/* Actions */}
                  <td style={{ textAlign: 'right' }}>
                    <div className="org-team-table-actions">
                      {/* View Details */}
                      <button
                        className="org-btn-table-action"
                        onClick={() => onViewDetails(team)}
                        type="button"
                        title="View team profile & equipment"
                      >
                        <span>Details</span>
                        <IconChevronRight size={13} />
                      </button>

                      {/* Quick Deploy if Available or On Standby */}
                      {(team.status === 'Available' || team.status === 'On Standby') && (
                        <button
                          className="org-btn-table-action deploy"
                          onClick={() => onQuickDeploy(team)}
                          type="button"
                          title="Deploy team to field incident"
                        >
                          <IconSend size={12} />
                          <span>Deploy</span>
                        </button>
                      )}

                      {/* Edit */}
                      <button
                        className="org-btn-table-action edit"
                        onClick={() => onEditTeam(team)}
                        type="button"
                        title="Edit team details"
                      >
                        <IconEdit size={12} />
                        <span>Edit</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
